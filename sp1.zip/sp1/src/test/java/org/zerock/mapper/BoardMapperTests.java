package org.zerock.mapper;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.zerock.dto.BoardDTO;

import lombok.extern.log4j.Log4j2;

@ExtendWith(SpringExtension.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j2
public class BoardMapperTests {

	@Autowired
	private BoardMapper boardMapper;
	
	@Test
	public void testInsert() {
		
		/*
		 * BoardDTO dto = new BoardDTO(); dto.setTitle("title");
		 * dto.setContent("content"); dto.setWriter("user00");
		 */
		
		BoardDTO dto = BoardDTO.builder() //요즘 트렌드는 이모양이다.
				.title("title1")
				.content("content1")
				.writer("writer1")
				.build();
		
		int insertCount = boardMapper.insert(dto);
		log.info("-------------------------------------");
		log.info("insertCount : " + insertCount);
		
		log.info("BNO : " + dto.getBno());
	}
	
	@Test
	public void testSelectOne() {
		BoardDTO boardDTO = boardMapper.selectOne(1L);
		
		log.info("boardDTO : " + boardDTO);
		
	}
	
	@Test
	public void testDelete() {
		int result = boardMapper.remove(2L);
		
		log.info("result : " + result);
	}
	
	@Test
	public void testUpdate() {
		BoardDTO dto = BoardDTO.builder()
				.title("new title")
				.content("new content")
				.delFlag(false)
				.bno(2L)
				.build();
		
		int result = boardMapper.update(dto);
		log.info("result : " + result);
				
	}
	
	@Test
	public void testSelect() {
		
		/*
		 * List<BoardDTO> list = boardMapper.list();
		 * 
		 * for(BoardDTO dto : list) log.info(dto);
		 */
		
		    //얘는 자바의 람다식
		boardMapper.list().forEach(dto->log.info(dto));
		
            //얘는 람다보다 더 줄인 버전.. 하지만 시인성이 좀 떨어지는 단점이 있다.		
		//boardMapper.list().forEach(log::info);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}

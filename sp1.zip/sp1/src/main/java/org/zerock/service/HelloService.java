package org.zerock.service;

import org.springframework.stereotype.Service;

@Service("hService")
public class HelloService {

}

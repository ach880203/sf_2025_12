package org.zerock.dto;

import lombok.Setter;
import lombok.ToString;

@Setter
@ToString
public class SampleDTO {
	private String name;
	private int age;
}

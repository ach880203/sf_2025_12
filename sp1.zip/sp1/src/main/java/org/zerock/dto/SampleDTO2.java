package org.zerock.dto;

import lombok.Setter;
import lombok.ToString;

@Setter
@ToString
public class SampleDTO2 {
	private String name;
	private String id;
}
